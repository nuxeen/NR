import random
import time
import argparse
from colorama import Fore, Style, init

init(autoreset=True)

BANNER = f"""
{Fore.CYAN}
   __  __                  _                 
  |  \/  | ___  _ __   ___| |_ ___  _ __ ___ 
  | |\/| |/ _ \| '_ \ / _ \ __/ _ \| '__/ _ \\
  | |  | | (_) | | | |  __/ || (_) | | |  __/
  |_|  |_|\___/|_| |_|\___|\__\___/|_|  \___|
  
     Made by Nuxeen brute force tool v1.0
{Style.RESET_ALL}
"""

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)",
    "Mozilla/5.0 (Linux; Android 11; SM-G991B)",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 14_0 like Mac OS X)",
    "Mozilla/5.0 (X11; Ubuntu; Linux x86_64)"
]

COUNTRIES = [
    "Germany", "France", "Netherlands", "United States", "Canada",
    "Brazil", "India", "Japan", "Australia", "Sweden", "Norway", "UK",
    "Italy", "Spain", "Morocco", "Egypt", "Russia", "Turkey", "China"
]

MLWL_FILE = "MLWL.txt"
CORRECT_PASSWORD = "pass321"

def random_ip():
    return ".".join(str(random.randint(1, 255)) for _ in range(4))

def random_country():
    return random.choice(COUNTRIES)

def log(msg, color=Fore.GREEN):
    print(f"{color}[+] {msg}{Style.RESET_ALL}")

def load_list(file_path):
    with open(file_path, "r", encoding="utf-8") as f:
        return [line.strip() for line in f if line.strip()]

def brute_force(url, admin_mode):
    passwords = load_list(MLWL_FILE)
    for password in passwords:
        user_agent = random.choice(USER_AGENTS)
        country = random_country()
        ip = random_ip()
        username = "admin" if admin_mode else password

        log(f"Trying {username}:{password}", color=Fore.YELLOW)
        print(f"IP: {ip} | Country: {country} | UA: {user_agent}")
        time.sleep(1)

        if password == CORRECT_PASSWORD:
            log(f"Success! Username: {username} | Password: {password}", color=Fore.CYAN)
            break

def main():
    parser = argparse.ArgumentParser(description="Nuxeen brute force tool")
    parser.add_argument("--url", required=True, help="Target login URL")
    parser.add_argument("--admin-check", action="store_true", help="Force admin mode")
    args = parser.parse_args()

    print(BANNER)

    admin_mode = args.admin_check or "admin" in args.url.lower()
    brute_force(args.url, admin_mode)

if __name__ == "__main__":
    main()