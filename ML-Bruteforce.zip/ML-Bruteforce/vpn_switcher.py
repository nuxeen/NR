import os
import random
import subprocess
import time

VPN_FOLDER = "vpn_profiles"

def switch_vpn():
    profiles = [f for f in os.listdir(VPN_FOLDER) if f.endswith(".ovpn")]
    if not profiles:
        return "No VPN profiles found"
    profile = random.choice(profiles)
    profile_path = os.path.join(VPN_FOLDER, profile)
    subprocess.run(["sudo", "killall", "openvpn"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    subprocess.Popen(["sudo", "openvpn", "--config", profile_path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    time.sleep(10)
    return profile
