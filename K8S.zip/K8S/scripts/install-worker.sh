bash ./common-setup.sh
bash ./join.sh
