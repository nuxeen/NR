# Kubernetes Simple Cluster Installer

## Overview

This project automates the installation of a simple Kubernetes cluster using bash scripts and kubeadm. It includes everything to get a basic 1 master + 2 worker setup running on Ubuntu 20.04, with Flannel CNI and a test NGINX application.

---

## Requirements

- 3 Linux VMs (Ubuntu 20.04)
  - 1 master, 2 workers
  - At least 2 CPUs, 2GB RAM per VM
- SSH access with sudo privileges
- Internet access on all machines

---

## Project Structure

k8s-simple-install/
├── config/ # Inventory and cluster settings
├── manifests/ # YAML for test app and dashboard
├── scripts/ # Bash install and deploy scripts
├── docs/ # Optional docs
└── read.md


---

## Step-by-Step Guide

### 1. Prepare Each Machine

Run the common setup script on each VM:

```bash
cd scripts
bash common-setup.sh

#Initialize the Master Node
bash install-master.sh

#Join Worker Nodes

bash install-worker.sh
#  Deploy a Test Application
   
  This deploys:

NGINX app exposed via NodePort

Kubernetes dashboard

bash deploy-test-app.sh
# Validation

kubectl get nodes
kubectl get pods -A
kubectl get svc


kubectl proxy
# Then open:
# http://localhost:8001/api/v1/namespaces/kubernetes-dashboard/services/https:kubernetes-dashboard:/proxy/


ts
sudo systemctl restart kubelet
kubectl describe pod <pod>
journalctl -xeu kubelet


