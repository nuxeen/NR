// SPDX-License-Identifier: MIT
pragma solidity ^0.8.28;

/// @title EventTickets
/// @notice Primary-sale tickets plus a peer-to-peer resale market.
contract EventTickets {
    // Immutable config (locked at construction)
    address public immutable owner;          // deployer; receives primary-sale revenue
    uint256 public immutable maxSupply;
    uint256 public immutable primaryPrice;   // in wei

    // Event metadata (string cannot be immutable)
    string public eventName;
    string public eventInfo;

    // Mutable state
    uint256 public ticketsSold;                     // also "next id" minus 1; ids start at 1
    mapping(uint256 => address) public ownerOf;     // id -> current owner
    mapping(uint256 => uint256) public listingPrice; // id -> resale price; 0 = not listed

    // Events
    event TicketBought(uint256 indexed id, address indexed buyer, uint256 price);
    event TicketListed(uint256 indexed id, address indexed seller, uint256 price);
    event ListingCancelled(uint256 indexed id, address indexed seller);
    event TicketResold(uint256 indexed id, address indexed from, address indexed to, uint256 price);

    // Errors
    error SoldOut();
    error WrongPayment(uint256 sent, uint256 required);
    error NotOwner();
    error NotListed();
    error ZeroPrice();
    error TransferFailed();

    constructor(
        string memory _name,
        string memory _info,
        uint256 _maxSupply,
        uint256 _primaryPriceWei
    ) {
        owner = msg.sender;
        maxSupply = _maxSupply;
        primaryPrice = _primaryPriceWei;
        eventName = _name;
        eventInfo = _info;
    }

    // Primary sale
    function buyTicket() external payable returns (uint256 id) {
        if (ticketsSold >= maxSupply) revert SoldOut();
        if (msg.value != primaryPrice) revert WrongPayment(msg.value, primaryPrice);

        id = ++ticketsSold;
        ownerOf[id] = msg.sender;

        _send(payable(owner), primaryPrice);
        emit TicketBought(id, msg.sender, primaryPrice);
    }

    // Secondary market: list
    function listForSale(uint256 id, uint256 price) external {
        if (ownerOf[id] != msg.sender) revert NotOwner();
        if (price == 0) revert ZeroPrice();

        listingPrice[id] = price;
        emit TicketListed(id, msg.sender, price);
    }

    // Secondary market: cancel
    function cancelListing(uint256 id) external {
        if (ownerOf[id] != msg.sender) revert NotOwner();
        if (listingPrice[id] == 0) revert NotListed();

        delete listingPrice[id];
        emit ListingCancelled(id, msg.sender);
    }

    // Secondary market: buy
    function buyListing(uint256 id) external payable {
        uint256 price = listingPrice[id];
        if (price == 0) revert NotListed();
        if (msg.value != price) revert WrongPayment(msg.value, price);

        address seller = ownerOf[id];

        // Effects (CEI): mutate state before the external transfer
        ownerOf[id] = msg.sender;
        delete listingPrice[id];

        // Interactions: pay the seller
        _send(payable(seller), price);
        emit TicketResold(id, seller, msg.sender, price);
    }

    // ETH helper (modern .call pattern)
    function _send(address payable to, uint256 amount) private {
        (bool ok, ) = to.call{value: amount}("");
        if (!ok) revert TransferFailed();
    }

    // Views
    function ticketsLeft() external view returns (uint256) {
        return maxSupply - ticketsSold;
    }

    function isListed(uint256 id) external view returns (bool) {
        return listingPrice[id] != 0;
    }
}
