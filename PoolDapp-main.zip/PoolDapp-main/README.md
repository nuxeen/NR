# Donation Pool DApp (Sepolia)

This is a minimal Donation Pool DApp: a trustless fundraising smart contract plus a single-file HTML frontend using ethers.js v6.

## What you get

- Solidity contract: immutable beneficiary + target, no admin powers.
- Frontend: connect MetaMask, donate, show progress, withdraw as beneficiary.

## 1) Deploy the contract (Remix)

1. Open https://remix.ethereum.org
2. Create a new file: contracts/DonationPool.sol
3. Paste the contents of [contracts/DonationPool.sol](contracts/DonationPool.sol)
4. Compile with Solidity `0.8.28` (or latest `0.8.x`) and enable optimization (200 runs).
5. Deploy to Sepolia using Injected Provider (MetaMask).
   - `_beneficiary`: an address you control (not the deployer).
   - `_targetWei`: use `0.1` ETH (Remix lets you pick ether units).
6. Copy the deployed contract address.

## 2) Run the frontend

1. Open [frontend/index.html](frontend/index.html)
2. Replace `CONTRACT_ADDRESS` with your deployed Sepolia address.
3. Serve the frontend directory (ES modules do not load over file://):

   ```bash
   cd frontend
   python3 -m http.server 8000
   ```

4. Visit http://localhost:8000 and click "Connect MetaMask".

## Notes

- Use Sepolia testnet only; do not send mainnet ETH.
- The deployer has no special privileges after deployment.
- The beneficiary is the only account that can withdraw once the target is reached.
