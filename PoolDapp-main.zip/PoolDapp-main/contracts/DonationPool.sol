// SPDX-License-Identifier: MIT
pragma solidity ^0.8.28;

/// @title DonationPool
/// @notice Trustless ETH fundraiser with immutable beneficiary and target.
contract DonationPool {
    // ── Immutable config (locked at construction) ────
    address public immutable owner;
    address public immutable beneficiary;
    uint256 public immutable targetAmount; // in wei

    // ── Mutable state ────────────────────────────────
    uint256 public totalRaised;
    bool public withdrawn;

    mapping(address => uint256) public donations;

    // ── Events ───────────────────────────────────────
    event Donated(address indexed donor, uint256 amount, uint256 newTotal);
    event TargetReached(uint256 finalAmount);
    event Withdrawn(address indexed by, uint256 amount);

    // ── Errors ───────────────────────────────────────
    error ZeroDonation();
    error AlreadyWithdrawn();
    error OnlyBeneficiary();
    error TargetNotReached(uint256 raised, uint256 target);
    error TransferFailed();

    constructor(address _beneficiary, uint256 _targetWei) {
        owner = msg.sender;
        beneficiary = _beneficiary;
        targetAmount = _targetWei;
    }

    /// @notice Anyone can donate any non-zero amount of ETH.
    function donate() external payable {
        if (msg.value == 0) revert ZeroDonation();
        if (withdrawn) revert AlreadyWithdrawn();

        bool wasBelowTarget = totalRaised < targetAmount;

        donations[msg.sender] += msg.value;
        totalRaised += msg.value;

        emit Donated(msg.sender, msg.value, totalRaised);

        if (wasBelowTarget && totalRaised >= targetAmount) {
            emit TargetReached(totalRaised);
        }
    }

    /// @notice Only the beneficiary can withdraw, only after target is met, only once.
    function withdraw() external {
        if (msg.sender != beneficiary) revert OnlyBeneficiary();
        if (totalRaised < targetAmount) revert TargetNotReached(totalRaised, targetAmount);
        if (withdrawn) revert AlreadyWithdrawn();

        withdrawn = true; // CEI pattern
        uint256 amount = address(this).balance;

        (bool ok, ) = payable(beneficiary).call{value: amount}("");
        if (!ok) revert TransferFailed();

        emit Withdrawn(beneficiary, amount);
    }

    // ── Views ───────────────────────────────────────
    function progressPercent() external view returns (uint256) {
        if (targetAmount == 0) return 0;
        uint256 p = (totalRaised * 100) / targetAmount;
        return p > 100 ? 100 : p;
    }

    function isTargetReached() external view returns (bool) {
        return totalRaised >= targetAmount;
    }

    function remaining() external view returns (uint256) {
        return totalRaised >= targetAmount ? 0 : targetAmount - totalRaised;
    }
}
