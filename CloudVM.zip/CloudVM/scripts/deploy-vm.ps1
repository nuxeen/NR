Import-Module VMware.PowerCLI
Start-Transcript -Path "../logs/deployment.log" -Append
. "$PSScriptRoot/functions.ps1"

$configPath = "../config/vm-config.json"
if (-Not (Test-Path $configPath)) {
    Write-Error "Missing config: $configPath"
    exit 1
}

$config = Get-Content $configPath | ConvertFrom-Json
Connect-ToVCenter -vcenter $config.vcenter -username $config.username -password $config.password
$template = Get-TemplateVM -templateName $config.template
Clone-VM -config $config -template $template

Stop-Transcript
