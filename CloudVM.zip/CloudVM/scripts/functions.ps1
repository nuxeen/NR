function Connect-ToVCenter {
    param ($vcenter, $username, $password)
    try {
        Connect-VIServer -Server $vcenter -User $username -Password $password -ErrorAction Stop
    } catch {
        Write-Error "Connection failed: $_"
        exit 1
    }
}

function Get-TemplateVM {
    param ($templateName)
    $template = Get-Template -Name $templateName -ErrorAction SilentlyContinue
    if (!$template) {
        Write-Error "Template not found: $templateName"
        exit 1
    }
    return $template
}

function Clone-VM {
    param ($config, $template)
    try {
        $vmhost = Get-Cluster $config.cluster | Get-VMHost | Get-Random
        $pool = Get-Cluster $config.cluster | Get-ResourcePool | Select-Object -First 1
        $vm = New-VM -Name $config.vm_name `
                     -Template $template `
                     -Datastore $config.datastore `
                     -VMHost $vmhost `
                     -ResourcePool $pool `
                     -NetworkName $config.network `
                     -ErrorAction Stop
        Set-VM -VM $vm -MemoryMB $config.memory -NumCpu $config.cpu -Confirm:$false
        Start-VM -VM $vm
        Write-Host "VM deployed: $($config.vm_name)"
    } catch {
        Write-Error "Deployment error: $_"
        exit 1
    }
}
