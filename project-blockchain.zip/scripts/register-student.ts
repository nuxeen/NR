import { createWalletClient, http, publicActions } from "viem";
import { privateKeyToAccount } from "viem/accounts";
import { localhost } from "viem/chains";
import dotenv from "dotenv";

dotenv.config();

// Standard ABI for the contract's register function
const roleManagerAbi = [
  {
    inputs: [
      { name: "_user", type: "address" },
      { name: "_group", type: "string" }
    ],
    name: "setUserRole",
    outputs: [],
    stateMutability: "nonpayable",
    type: "function"
  }
];

async function main() {
  // Hardhat Account #0 private key (The default contract deployer/admin)
  const ADMIN_PRIVATE_KEY = "0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80";
  const account = privateKeyToAccount(ADMIN_PRIVATE_KEY);

  const walletClient = createWalletClient({
    account,
    chain: localhost,
    transport: http("http://127.0.0.1:8545"),
  }).extend(publicActions);

  // ⚠️ REPLACE THIS STRING WITH YOUR ACTUAL METAMASK WALLET ADDRESS!
  const STUDENT_METAMASK_ADDRESS = "0xYOUR_METAMASK_ADDRESS_HERE"; 

  console.log(`Registering address ${STUDENT_METAMASK_ADDRESS} as a verified 'ComputerScience' student...`);

  const { request } = await walletClient.simulateContract({
    address: "0x5FbDB2315678afecb367f032d93F642f64180aa3", // RoleManager address
    abi: roleManagerAbi,
    name: "setUserRole",
    args: [STUDENT_METAMASK_ADDRESS, "ComputerScience"],
  });

  const hash = await walletClient.writeContract(request);
  console.log(`✓ Registration transaction broadcasted! Hash: ${hash}`);
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});