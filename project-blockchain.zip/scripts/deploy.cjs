const hre = require("hardhat");

async function main() {
  // Get the viem helper from the Hardhat Runtime Environment
  const viem = hre.viem;
  
  // Get the default account (the deployer admin)
  const [admin] = await viem.getWalletClients();
  console.log(`🚀 Starting deployment with account: ${admin.account.address}`);

  // 1. Deploy RoleManager
  const roleManager = await viem.deployContract("RoleManager", [admin.account.address]);
  console.log(`✅ RoleManager deployed to: ${roleManager.address}`);

  // 2. Deploy AcademicRegistry, linking it to RoleManager
  const academicRegistry = await viem.deployContract("AcademicRegistry", [roleManager.address]);
  console.log(`✅ AcademicRegistry deployed to: ${academicRegistry.address}`);

  console.log("\n🔥 System fully live on your local node! Update your server/.env with these addresses.");
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });