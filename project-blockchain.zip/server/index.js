import { initializeVectorStore, handleStudentQuery } from "./services.js";
import express from "express";
import cors from "cors";

const app = express();
app.use(cors());
app.use(express.json());

app.post("/api/chat", async (req, res) => {
  const { studentAddress, question } = req.body;
  
  if (!studentAddress || !question) {
    return res.status(400).json({ error: "Missing wallet address identity or input question." });
  }

  try {
    const result = await handleStudentQuery(studentAddress, question);
    res.json(result);
  } catch (error) {
    res.status(403).json({ error: error.message });
  }
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, async () => {
  console.log(`🌐 Academic Assistant Backend active on port ${PORT}`);
  try {
    await initializeVectorStore();
    console.log("🚀 Gemini RAG Vector Store ready");
  } catch (e) {
    console.error("Vector initialization failed:", e);
  }
});