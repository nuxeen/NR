import { GoogleGenAI } from "@google/genai";
import { createPublicClient, http } from "viem";
import { localhost } from "viem/chains";
import dotenv from "dotenv";
import path from "path";

// Load environment variables dynamically
dotenv.config({ path: path.resolve(process.cwd(), "../.env") });

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

// Connect to local Hardhat blockchain ledger
const publicClient = createPublicClient({
  chain: localhost,
  transport: http("http://127.0.0.1:8545"),
});

// ABI descriptors for reading role permissions
const roleManagerAbi = [
  {
    inputs: [{ name: "_address", type: "address" }],
    name: "getUserGroup",
    outputs: [{ name: "", type: "string" }],
    stateMutability: "view",
    type: "function",
  }
];

let mockVectorStore = [];

export async function initializeVectorStore() {
  // Pre-loaded verified institutional data context
  const documents = [
    "Final Blockchain Exam is on June 15th, 2026 at 14:00 in Room 401. Bring an offline calculator.",
    "The Smart Contract project deadline is extended to June 1st, 2026. Submissions via github links.",
    "Cryptographic Engineering office hours are held every Tuesday from 10:00 AM to 12:00 PM by Dr. Smith.",
    "Advanced AI Architecture project milestones are due on June 10th, 2026. Submit through the portal."
  ];
  mockVectorStore = documents;
}

export async function handleStudentQuery(studentAddress, question) {
  // 1. Query the local blockchain ledger to confirm role access rights
  const group = await publicClient.readContract({
    address: process.env.ROLE_MANAGER_ADDRESS || "0x5FbDB2315678afecb367f032d93F642f64180aa3",
    abi: roleManagerAbi,
    name: "getUserGroup",
    args: [studentAddress],
  });

  if (!group || group === "") {
    throw new Error(`Permission Denied: Address ${studentAddress} is not verified inside RoleManager.`);
  }

  // 2. Perform localized structural RAG lookup matching
  const relevantContext = mockVectorStore
    .filter(doc => doc.toLowerCase().includes("blockchain") || doc.toLowerCase().includes("project") || doc.toLowerCase().includes("deadline"))
    .join("\n");

  // 3. Prompt Gemini with institutional boundaries
  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash",
    contents: `
      You are a verified decentralized Academic Assistant.
      Student Group Role: ${group}
      Verified System Context Data:
      ${relevantContext}
      
      Student Query: ${question}
      
      Provide an accurate, friendly answer strictly utilizing the provided context. If the answer isn't in the context, say you don't possess that data.
    `,
  });

  return {
    verifiedGroupOnChain: group,
    answer: response.text
  };
}