import { buildModule } from "@nomicfoundation/hardhat-ignition/modules";

const AcademicAssistantModule = buildModule("AcademicAssistantModule", (m) => {
  // 1. We fetch or generate an admin address. 
  // By default, account[0] will be our administrator.
  const adminAddress = m.getAccount(0);

  // 2. Deploy the RoleManager contract first, passing the admin address to the constructor
  const roleManager = m.contract("RoleManager", [adminAddress]);

  // 3. Deploy the AcademicRegistry contract next, passing the newly deployed RoleManager's address
  const academicRegistry = m.contract("AcademicRegistry", [roleManager]);

  return { roleManager, academicRegistry };
});

export default AcademicAssistantModule;