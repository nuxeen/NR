import { expect } from "chai";
import { network } from "hardhat";
import { keccak256, toHex } from "viem";
import { describe, it } from "node:test";

describe("Decentralised Academic Assistant System", async function () {
  async function deployFixture() {
    // Hardhat 3 Native Pattern: Spin up a fresh local network ledger connection
    const { viem } = await network.create();

    const [admin, professor, student, outsider] = await viem.getWalletClients();

    const roleManager = await viem.deployContract("RoleManager", [admin.account.address]);
    const academicRegistry = await viem.deployContract("AcademicRegistry", [roleManager.address]);
    const publicClient = await viem.getPublicClient();

    return { roleManager, academicRegistry, admin, professor, student, outsider, publicClient };
  }

  it("Should allow Admin to register roles and assign a group", async function () {
    const { roleManager, admin, professor, student } = await deployFixture();

    await roleManager.write.registerProfessor([professor.account.address], { account: admin.account });
    await roleManager.write.registerStudent([student.account.address, "MF1"], { account: admin.account });

    const isProf = await roleManager.read.hasRole([await roleManager.read.PROFESSOR_ROLE(), professor.account.address]);
    const group = await roleManager.read.getStudentGroup([student.account.address]);

    if (!isProf || group !== "MF1") throw new Error("Role setup failed");
  });

  it("Should prevent an outsider from publishing announcements", async function () {
    const { academicRegistry, outsider } = await deployFixture();
    const dummyHash = keccak256(toHex("Exam tomorrow"));

    try {
      await academicRegistry.write.publishAnnouncement([dummyHash, "MF1"], { account: outsider.account });
      throw new Error("Should have failed");
    } catch (err: any) {
      if (!err.message.includes("Caller is not a professor")) throw err;
    }
  });

  it("Should control announcement signature permissions based on groups", async function () {
    const { roleManager, academicRegistry, admin, professor, student, outsider } = await deployFixture();
    
    await roleManager.write.registerProfessor([professor.account.address], { account: admin.account });
    await roleManager.write.registerStudent([student.account.address, "MF1"], { account: admin.account });
    await roleManager.write.registerStudent([outsider.account.address, "MF2"], { account: admin.account });

    const dummyHash = keccak256(toHex("Deadline Friday"));
    await academicRegistry.write.publishAnnouncement([dummyHash, "MF1"], { account: professor.account });

    // MF1 student works perfectly
    await academicRegistry.write.acknowledgeAnnouncement([1n], { account: student.account });

    // MF2 student fails elegantly
    try {
      await academicRegistry.write.acknowledgeAnnouncement([1n], { account: outsider.account });
      throw new Error("Should have failed for wrong group");
    } catch (err: any) {
      if (!err.message.includes("Announcement not targeted at your group")) throw err;
    }
  });
});