import { HardhatUserConfig } from "hardhat/config";
import "@nomicfoundation/hardhat-viem";
import * as dotenv from "dotenv";

// Load the local .env file variables
dotenv.config();

const config: HardhatUserConfig = {
  solidity: {
    version: "0.8.28",
    settings: {
      optimizer: {
        enabled: true,
        runs: 200,
      },
    },
  },
  networks: {
    // This is the network configuration for your local 'npx hardhat node'
    localhost: {
      url: "http://127.0.0.1:8545",
    },
    hardhat: {
      // Configuration for the in-memory test network runner
    }
  },
};

export default config;