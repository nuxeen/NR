// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/access/AccessControl.sol";

contract RoleManager is AccessControl {
    bytes32 public constant PROFESSOR_ROLE = keccak256("PROFESSOR_ROLE");
    bytes32 public constant STUDENT_ROLE = keccak256("STUDENT_ROLE");

    mapping(address => string) private _studentGroups;

    event StudentRegistered(address indexed student, string group);
    event ProfessorRegistered(address indexed professor);

    constructor(address rootAdmin) {
        _grantRole(DEFAULT_ADMIN_ROLE, rootAdmin);
    }

    function registerProfessor(address professor) external onlyRole(DEFAULT_ADMIN_ROLE) {
        grantRole(PROFESSOR_ROLE, professor);
        emit ProfessorRegistered(professor);
    }

    function registerStudent(address student, string calldata group) external onlyRole(DEFAULT_ADMIN_ROLE) {
        grantRole(STUDENT_ROLE, student);
        _studentGroups[student] = group;
        emit StudentRegistered(student, group);
    }

    function getStudentGroup(address student) external view returns (string memory) {
        require(hasRole(STUDENT_ROLE, student), "Address is not a registered student");
        return _studentGroups[student];
    }
}