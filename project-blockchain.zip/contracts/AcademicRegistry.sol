// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "./RoleManager.sol";

contract AcademicRegistry {
    RoleManager public immutable roleManager;

    struct Announcement {
        uint256 id;
        address professor;
        bytes32 contentHash; 
        string targetGroup;  
        uint256 timestamp;
    }

    uint256 private _announcementIds;
    
    mapping(uint256 => Announcement) private _announcements;
    mapping(bytes32 => bytes32) private _documentRegistry;
    mapping(uint256 => mapping(address => bool)) private _acknowledgments;

    event AnnouncementPublished(uint256 indexed id, address indexed professor, string targetGroup);
    event DocumentRegistered(bytes32 indexed docId, bytes32 integrityHash);
    event Acknowledged(uint256 indexed announcementId, address indexed student);

    constructor(address _roleManagerAddress) {
        roleManager = RoleManager(_roleManagerAddress);
    }

    function publishAnnouncement(bytes32 contentHash, string calldata targetGroup) external {
        require(roleManager.hasRole(roleManager.PROFESSOR_ROLE(), msg.sender), "Caller is not a professor");
        
        _announcementIds++;
        _announcements[_announcementIds] = Announcement({
            id: _announcementIds,
            professor: msg.sender,
            contentHash: contentHash,
            targetGroup: targetGroup,
            timestamp: block.timestamp
        });

        emit AnnouncementPublished(_announcementIds, msg.sender, targetGroup);
    }

    function registerDocument(bytes32 docId, bytes32 integrityHash) external {
        require(roleManager.hasRole(roleManager.PROFESSOR_ROLE(), msg.sender), "Caller is not a professor");
        _documentRegistry[docId] = integrityHash;
        emit DocumentRegistered(docId, integrityHash);
    }

    function acknowledgeAnnouncement(uint256 announcementId) external {
        require(roleManager.hasRole(roleManager.STUDENT_ROLE(), msg.sender), "Caller is not a student");
        
        Announcement memory announcement = _announcements[announcementId];
        string memory studentGroup = roleManager.getStudentGroup(msg.sender);
        
        require(keccak256(bytes(announcement.targetGroup)) == keccak256(bytes(studentGroup)), "Announcement not targeted at your group");
        require(!_acknowledgments[announcementId][msg.sender], "Already acknowledged");

        _acknowledgments[announcementId][msg.sender] = true;
        emit Acknowledged(announcementId, msg.sender);
    }

    function getAnnouncement(uint256 id) external view returns (Announcement memory) {
        return _announcements[id];
    }

    function verifyDocument(bytes32 docId) external view returns (bytes32) {
        return _documentRegistry[docId];
    }

    function hasAcknowledged(uint256 announcementId, address student) external view returns (bool) {
        return _acknowledgments[announcementId][student];
    }
}