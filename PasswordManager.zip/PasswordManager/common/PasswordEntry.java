package common;

import java.io.Serializable;

public class PasswordEntry implements Serializable {
    private String site, username, password;

    public PasswordEntry(String s, String u, String p) {
        site = s;
        username = u;
        password = p;
    }

    public String getSite() {
        return site;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }
}
