package storage;

import common.PasswordEntry;
import common.User;

import java.util.*;

public class DataStore {
    private static Map<String, User> users = new HashMap<>();
    private static Map<String, List<PasswordEntry>> passwords = new HashMap<>();

    static {
        users.put("alice", new User("alice", "03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4")); // 1234
    }

    public static boolean checkCredentials(String u, String h) {
        User user = users.get(u);
        return user != null && user.getHashedPassword().equals(h);
    }

    public static void addPasswordEntry(String u, PasswordEntry e) {
        passwords.computeIfAbsent(u, k -> new ArrayList<>()).add(e);
    }

    public static List<PasswordEntry> getPasswordEntries(String u) {
        return passwords.getOrDefault(u, new ArrayList<>());
    }

    public static List<PasswordEntry> searchEntries(String u, String k) {
        List<PasswordEntry> all = getPasswordEntries(u);
        List<PasswordEntry> result = new ArrayList<>();
        for (PasswordEntry e : all) {
            if (e.getSite().contains(k) || e.getUsername().contains(k)) {
                result.add(e);
            }
        }
        return result;
    }
}
