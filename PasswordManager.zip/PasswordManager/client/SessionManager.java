package client;

public class SessionManager {
    private static String user;

    public static void setUser(String u) {
        user = u;
    }

    public static String getUser() {
        return user;
    }
}
