package client;

import common.PasswordEntry;
import server.IPasswordManager;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class MainPage extends JFrame {
    private DefaultListModel<String> model = new DefaultListModel<>();
    private JList<String> list = new JList<>(model);
    private IPasswordManager stub;
    private List<PasswordEntry> entries;

    public MainPage(IPasswordManager s) {
        stub = s;
        setTitle("Password Manager");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        JButton add = new JButton("Add");
        JButton search = new JButton("Search");
        JTextField query = new JTextField();
        JPanel top = new JPanel(new BorderLayout());
        top.add(query, BorderLayout.CENTER);
        top.add(search, BorderLayout.EAST);
        add(top, BorderLayout.NORTH);
        add(new JScrollPane(list), BorderLayout.CENTER);
        add(add, BorderLayout.SOUTH);

        refresh();

        search.addActionListener(e -> {
            try {
                entries = stub.searchEntries(SessionManager.getUser(), query.getText());
                refreshList();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        add.addActionListener(e -> new AddEditDialog(this, stub));
    }

    public void refresh() {
        try {
            entries = stub.getEntries(SessionManager.getUser());
            refreshList();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void refreshList() {
        model.clear();
        for (PasswordEntry e : entries) {
            model.addElement(e.getSite() + " | " + e.getUsername());
        }
    }
}
