package client;

import server.IPasswordManager;
import utils.SecurityUtils;

import javax.swing.*;
import java.awt.*;
import java.rmi.Naming;

public class LoginPage extends JFrame {
    private JTextField uField = new JTextField();
    private JPasswordField pField = new JPasswordField();

    public LoginPage() {
        setTitle("Login");
        setSize(300, 150);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(3, 2));
        add(new JLabel("Username:"));
        add(uField);
        add(new JLabel("Password:"));
        add(pField);
        JButton b = new JButton("Login");
        add(new JLabel());
        add(b);

        b.addActionListener(e -> {
            try {
                IPasswordManager stub = (IPasswordManager) Naming.lookup("rmi://localhost/PasswordManager");
                String u = uField.getText();
                String p = new String(pField.getPassword());
                if (!SecurityUtils.validInput(u) || !SecurityUtils.validInput(p)) {
                    JOptionPane.showMessageDialog(this, "Invalid input");
                    return;
                }
                if (stub.login(u, p)) {
                    SessionManager.setUser(u);
                    new MainPage(stub).setVisible(true);
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(this, "Login failed");
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });
    }
}
