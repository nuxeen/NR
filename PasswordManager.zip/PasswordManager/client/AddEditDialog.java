package client;

import common.PasswordEntry;
import server.IPasswordManager;
import utils.SecurityUtils;

import javax.swing.*;
import java.awt.*;

public class AddEditDialog extends JDialog {
    public AddEditDialog(JFrame parent, IPasswordManager stub) {
        super(parent, "Add Password", true);
        setSize(300, 200);
        setLayout(new GridLayout(4, 2));
        setLocationRelativeTo(parent);
        JTextField site = new JTextField();
        JTextField user = new JTextField();
        JTextField pass = new JTextField();
        JButton save = new JButton("Save");
        add(new JLabel("Site:"));
        add(site);
        add(new JLabel("Username:"));
        add(user);
        add(new JLabel("Password:"));
        add(pass);
        add(new JLabel());
        add(save);

        save.addActionListener(e -> {
            String s = site.getText(), u = user.getText(), p = pass.getText();
            if (!SecurityUtils.validInput(s) || !SecurityUtils.validInput(u) || !SecurityUtils.validInput(p)) {
                JOptionPane.showMessageDialog(this, "Invalid input");
                return;
            }
            try {
                stub.addEntry(SessionManager.getUser(), new PasswordEntry(s, u, p));
                ((MainPage) parent).refresh();
                dispose();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        setVisible(true);
    }
}
