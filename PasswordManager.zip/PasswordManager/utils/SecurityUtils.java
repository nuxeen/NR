package utils;

import java.security.MessageDigest;

public class SecurityUtils {
    public static String hash(String s) {
        try {
            MessageDigest d = MessageDigest.getInstance("SHA-256");
            byte[] b = d.digest(s.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte c : b) sb.append(String.format("%02x", c));
            return sb.toString();
        } catch (Exception e) {
            return null;
        }
    }

    public static boolean validInput(String s) {
        return s != null && !s.trim().isEmpty() && s.length() <= 100;
    }
}
