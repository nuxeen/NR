package server;

import common.PasswordEntry;
import storage.DataStore;
import utils.SecurityUtils;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.List;

public class PasswordManagerImpl extends UnicastRemoteObject implements IPasswordManager {
    public PasswordManagerImpl() throws RemoteException {
        super();
    }

    public boolean login(String u, String p) {
        return DataStore.checkCredentials(u, SecurityUtils.hash(p));
    }

    public void addEntry(String u, PasswordEntry e) {
        DataStore.addPasswordEntry(u, e);
    }

    public List<PasswordEntry> getEntries(String u) {
        return DataStore.getPasswordEntries(u);
    }

    public List<PasswordEntry> searchEntries(String u, String k) {
        return DataStore.searchEntries(u, k);
    }
}
