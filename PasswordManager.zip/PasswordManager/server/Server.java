package server;

import java.rmi.Naming;

public class Server {
    public static void main(String[] args) {
        try {
            Naming.rebind("PasswordManager", new PasswordManagerImpl());
            System.out.println("Server started...");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
