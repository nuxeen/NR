package server;

import common.PasswordEntry;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

public interface IPasswordManager extends Remote {
    boolean login(String u, String p) throws RemoteException;
    void addEntry(String u, PasswordEntry e) throws RemoteException;
    List<PasswordEntry> getEntries(String u) throws RemoteException;
    List<PasswordEntry> searchEntries(String u, String keyword) throws RemoteException;
}
