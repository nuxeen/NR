import logging
import os
import requests
from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes
# 1. Import the official Google GenAI library
from google import genai

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)

TELEGRAM_TOKEN = "8551744261:AAHQyh9bImxJimK1sXpTmgd8DMJp6bZeync"
GITLAB_URL = "https://gitlab.com"
GITLAB_PROJECT_ID = "YOUR_PROJECT_ID"
GITLAB_PRIVATE_TOKEN = "YOUR_PRIVATE_ACCESS_TOKEN"

GEMINI_API_KEY = "YOUR_GEMINI_API_KEY"

HEADERS = {"PRIVATE-TOKEN": GITLAB_PRIVATE_TOKEN}


ai_client = genai.Client(api_key=GEMINI_API_KEY)

def analyze_with_ai(raw_data: str, context_type: str) -> str:
    
    try:
        prompt = (
            f"You are an expert DevSecOps AI Assistant. Analyze the following raw {context_type} "
            f"from a GitLab CI/CD pipeline. Identify any security issues, failures, or vulnerabilities, "
            f"and provide a concise, professional summary and recommendations for the developer. "
            f"Do not use any emojis in your response.\n\nRaw Data:\n{raw_data}"
        )
        
        # Call the Gemini 2.5 Flash model (excellent for fast text and log analysis , but 3.5 is also an option :) )
        response = ai_client.models.generate_content(
            model='gemini-2.5-flash',
            contents=prompt,
        )
        return response.text
    except Exception as e:
        logger.error(f"AI Analysis Error: {e}")
        return f"Error: AI engine was unable to analyze the data. Raw stream fallback:\n{raw_data[:500]}"

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    await update.message.reply_markdown_v2(
        fr"AI DevSecOps Agent Active\. Welcome {user.mention_markdown_v2()}\. Use /help to view commands\."
    )

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    help_text = (
        "Agent Command Console:\n\n"
        "/start \- Initialize agent\n"
        "/status \- View pipeline and deployment status\n"
        "/run\_pipeline \- Trigger full DevSecOps workflow\n"
        "/scan \- Run AI security vulnerability audit\n"
        "/deploy \- Deploy build to production\n"
        "/logs \- View AI log analysis report\n"
        "/help \- Display this menu"
    )
    await update.message.reply_markdown_v2(help_text)

async def status(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    url = f"{GITLAB_URL}/api/v4/projects/{GITLAB_PROJECT_ID}/pipelines"
    try:
        response = requests.get(url, headers=HEADERS, params={"per_page": 1})
        if response.status_code == 200 and response.json():
            latest_pipeline = response.json()[0]
            pipeline_status = latest_pipeline["status"]
            pipeline_id = latest_pipeline["id"]
            
            report = (
                f"System Status Report\n\n"
                f"Pipeline ID: {pipeline_id}\n"
                f"Pipeline State: {pipeline_status}\n"
            )
            await update.message.reply_text(report)
        else:
            await update.message.reply_text("No pipeline history found or failed to fetch status.")
    except Exception as e:
        logger.error(e)
        await update.message.reply_text("Error connection failure to GitLab API.")

async def run_pipeline(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    url = f"{GITLAB_URL}/api/v4/projects/{GITLAB_PROJECT_ID}/pipeline"
    try:
        response = requests.post(url, headers=HEADERS, params={"ref": "main"})
        if response.status_code == 201:
            data = response.json()
            await update.message.reply_text(f"Pipeline initiated successfully. ID: {data['id']} Status: {data['status']}")
        else:
            await update.message.reply_text(f"Failed to trigger pipeline. Status code: {response.status_code}")
    except Exception as e:
        logger.error(e)
        await update.message.reply_text("Error sending trigger request to GitLab.")

async def scan(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    url = f"{GITLAB_URL}/api/v4/projects/{GITLAB_PROJECT_ID}/pipelines"
    try:
        response = requests.get(url, headers=HEADERS, params={"per_page": 1})
        if response.status_code == 200 and response.json():
            latest_pipeline = response.json()[0]
            p_id = latest_pipeline["id"]
            jobs_url = f"{GITLAB_URL}/api/v4/projects/{GITLAB_PROJECT_ID}/pipelines/{p_id}/jobs"
            jobs_resp = requests.get(jobs_url, headers=HEADERS)
            
            if jobs_resp.status_code == 200:
                jobs = jobs_resp.json()
                scan_results = "Security Scans Posture:\n\n"
                raw_jobs_summary = ""
                for job in jobs:
                    if any(x in job["name"].lower() for x in ["sast", "dependency", "docker", "secret"]):
                        raw_jobs_summary += f"Job Name: {job['name']}, Status: {job['status']}, Stage: {job['stage']}\n"
                
                if raw_jobs_summary:
                    await update.message.reply_text("Forwarding scan profiles to AI analysis engine...")
                    # 4. Process the raw jobs list using AI before replying
                    ai_analysis = analyze_with_ai(raw_jobs_summary, "Security Scan Configuration Results")
                    await update.message.reply_text(ai_analysis)
                else:
                    await update.message.reply_text("No explicit security scan jobs found in the current pipeline sequence.")
            else:
                await update.message.reply_text("Failed to fetch jobs for security scans matching.")
        else:
            await update.message.reply_text("No active or historical pipeline records found.")
    except Exception as e:
        logger.error(e)
        await update.message.reply_text("Error fetching security audit information.")

async def deploy(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    url = f"{GITLAB_URL}/api/v4/projects/{GITLAB_PROJECT_ID}/pipelines"
    try:
        response = requests.get(url, headers=HEADERS, params={"per_page": 1})
        if response.status_code == 200 and response.json():
            latest_pipeline = response.json()[0]
            p_id = latest_pipeline["id"]
            jobs_url = f"{GITLAB_URL}/api/v4/projects/{GITLAB_PROJECT_ID}/pipelines/{p_id}/jobs"
            jobs_resp = requests.get(jobs_url, headers=HEADERS)
            
            if jobs_resp.status_code == 200:
                jobs = jobs_resp.json()
                deploy_job = None
                for job in jobs:
                    if "deploy" in job["name"].lower():
                        deploy_job = job
                        break
                
                if deploy_job:
                    if deploy_job["status"] == "manual":
                        play_url = f"{GITLAB_URL}/api/v4/projects/{GITLAB_PROJECT_ID}/jobs/{deploy_job['id']}/play"
                        play_resp = requests.post(play_url, headers=HEADERS)
                        if play_resp.status_code == 200:
                            await update.message.reply_text("Deployment sequence authorized and initiated.")
                        else:
                            await update.message.reply_text("Failed to trigger deployment job block.")
                    else:
                        await update.message.reply_text(f"Deployment job state is {deploy_job['status']}. Cannot execute manual trigger.")
                else:
                    await update.message.reply_text("No explicit deployment job stage discovered in current pipeline.")
            else:
                await update.message.reply_text("Failed to resolve jobs list index infrastructure.")
        else:
            await update.message.reply_text("No active pipeline context exists to execute deployment.")
    except Exception as e:
        logger.error(e)
        await update.message.reply_text("Error processing production deployment verification.")

async def logs(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    url = f"{GITLAB_URL}/api/v4/projects/{GITLAB_PROJECT_ID}/pipelines"
    try:
        response = requests.get(url, headers=HEADERS, params={"per_page": 1})
        if response.status_code == 200 and response.json():
            latest_pipeline = response.json()[0]
            p_id = latest_pipeline["id"]
            jobs_url = f"{GITLAB_URL}/api/v4/projects/{GITLAB_PROJECT_ID}/pipelines/{p_id}/jobs"
            jobs_resp = requests.get(jobs_url, headers=HEADERS)
            
            if jobs_resp.status_code == 200 and jobs_resp.json():
                latest_job = jobs_resp.json()[0]
                job_id = latest_job["id"]
                log_url = f"{GITLAB_URL}/api/v4/projects/{GITLAB_PROJECT_ID}/jobs/{job_id}/trace"
                log_resp = requests.get(log_url, headers=HEADERS)
                
                if log_resp.status_code == 200:
                    log_text = log_resp.text[-2000:] # Pull a larger log chunk for better AI insight
                    await update.message.reply_text(f"Analyzing live logs from job ({latest_job['name']}) via AI...")
                    # 5. Process raw text streams using AI
                    ai_analysis = analyze_with_ai(log_text, f"GitLab Terminal Output Logs for Job {latest_job['name']}")
                    await update.message.reply_text(ai_analysis)
                else:
                    await update.message.reply_text("Failed to extract raw log stdout trace.")
            else:
                await update.message.reply_text("No execution jobs found inside the pipeline sequence.")
        else:
            await update.message.reply_text("No pipeline records match logging request requests.")
    except Exception as e:
        logger.error(e)
        await update.message.reply_text("Error communicating with logging endpoints database backend.")

def main() -> None:
    application = Application.builder().token(TELEGRAM_TOKEN).build()

    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("status", status))
    application.add_handler(CommandHandler("run_pipeline", run_pipeline))
    application.add_handler(CommandHandler("scan", scan))
    application.add_handler(CommandHandler("deploy", deploy))
    application.add_handler(CommandHandler("logs", logs))

    print("AI DevSecOps Agent Engine Online. Polling active...")
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    main()
