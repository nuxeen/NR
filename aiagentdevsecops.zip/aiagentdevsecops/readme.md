# AI DevSecOps Management Agent via Telegram

This project implements an intelligent DevSecOps management agent that interfaces with users via Telegram to interactively control, audit, and deploy software changes through a GitLab CI/CD pipeline backend.

## Architecture Layout

The platform handles secure messaging routing and pipeline execution pipelines over the following minimum infrastructure flow:
Telegram User -> Telegram Bot Engine -> Python DevSecOps Agent -> GitLab REST API -> Docker Runners -> Embedded Security Utilities

## Functional Commands Implemented

The management core maps the following operational handlers directly inside the communication thread:

- /start - Initial session bootstrap and handshake verification.
- /help - Display the automated assistance documentation console.
- /status - Query the latest GitLab pipeline state matrix and cached records.
- /run_pipeline - Dispatch an execution payload trigger to launch the integration workflow.
- /scan - Audit real-time container configurations, SAST results, dependencies, and secret scans.
- /deploy - Release verified software artifacts to production layers safely.
- /logs - Fetch and display raw execution logs directly from active container runtimes.

## Local Deployment

### Prerequisites
- Docker Engine installed locally
- Docker Compose utility package

### Launching the Environment

1. Update the environment variables configuration block inside the `docker-compose.yml` orchestrator file with your active GitLab credentials:
   - `GITLAB_PROJECT_ID`
   - `GITLAB_PRIVATE_TOKEN`

2. Build and initiate the background container orchestration stack:
   ```bash
   docker compose up --build -d
