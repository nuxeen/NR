SECURECHAT: END-TO-END ENCRYPTED MESSAGING SYSTEM
SecureChat is a high-security Android communication platform designed with a Security-First architecture. It implements industry-standard AES-GCM encryption and hardware-backed key management to ensure that messages remain private, even if the cloud infrastructure is compromised.
SECURITY FEATURES
1. END-TO-END ENCRYPTION (E2EE)
 * Algorithm: AES-256 in GCM (Galois/Counter Mode).
 * Process: Data is encrypted on the sender's device and only decrypted on the receiver's device.
 * Storage: Firebase only stores the encrypted ciphertext and the Initialization Vector (IV).
2. HARDWARE-BACKED KEY MANAGEMENT
 * Android KeyStore: Cryptographic keys are generated and stored in the device's Trusted Execution Environment (TEE) or Secure Element (SE).
 * Accessibility: Keys never leave the hardware, making them immune to extraction by rooted users or external malware.
3. BIOMETRIC AUTHENTICATION
 * Integration: Uses the Android BiometricPrompt API.
 * Requirement: Mandates Fingerprint or Face Unlock before accessing the application's decrypted database or messaging interface.
4. ANTI-TAMPER AND ROOT DETECTION
 * Environment Integrity: The app performs real-time checks for su binaries and known rooting applications.
 * Security Lockdown: If a compromised environment is detected, the app immediately terminates to prevent memory dumping or process injection.
5. CODE OBFUSCATION
 * Implementation: Uses R8/ProGuard to shrink, optimize, and obfuscate the source code.
 * Reverse Engineering Protection: Renames classes and methods to unreadable characters to prevent analysis of the security logic.
TECH STACK
 * Language: Kotlin
 * Backend: Firebase (Authentication and Firestore)
 * Security APIs: AndroidKeyStore, Biometric API, AES-GCM
 * Architecture: MVVM / Clean Architecture
INSTALLATION AND SETUP
 * Clone the repository.
 * Add the google-services.json file to the /app directory.
 * Enable Email/Password and Firestore in the Firebase Console.
 * Build the project using Android Studio.
LICENSE
This project is for educational purposes as part of a Cybersecurity Capstone.
