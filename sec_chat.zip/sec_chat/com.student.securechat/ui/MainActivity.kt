package com.student.securechat.ui

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.student.securechat.core.security.BiometricAuth

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        val biometricAuth = BiometricAuth(this)
        biometricAuth.showPrompt(
            onSuccess = {
                setupAppContent()
            },
            onError = {
                Toast.makeText(this, "Authentication Failed", Toast.LENGTH_SHORT).show()
                finish()
            }
        )
    }

val pulse = AnimationUtils.loadAnimation(this, R.anim.pulse)
binding.ivFingerprint.startAnimation(pulse)


    private fun setupAppContent() {
        setContentView(R.layout.activity_main)
    }
}
