package com.student.securechat.ui.chat

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.student.securechat.core.security.CryptoManager
import com.student.securechat.data.remote.ChatService
import com.student.securechat.databinding.ActivityChatBinding

class ChatActivity : AppCompatActivity() {
    private lateinit var binding: ActivityChatBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityChatBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupListeners()
        observeMessages()
    }

    private fun setupListeners() {
        binding.btnSend.setOnClickListener {
            val text = binding.etMessage.text.toString()
            if (text.isNotEmpty()) {
              
                [span_3](start_span)ChatService.sendMessage("sender_id", "receiver_id", text)[span_3](end_span)
                binding.etMessage.text.clear()
            }
        }
    }

    private fun observeMessages() {
        ChatService.listenForMessages { message ->
            
            [span_4](start_span)val decryptedText = CryptoManager.decrypt(message.encryptedText)[span_4](end_span)
            updateUI(decryptedText) 
        }
    }

    private fun updateUI(text: String) {
        
    }
}
