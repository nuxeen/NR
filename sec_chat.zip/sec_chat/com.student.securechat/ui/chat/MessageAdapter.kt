package com.student.securechat.ui.chat

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.student.securechat.R
import com.student.securechat.data.model.Message

class MessageAdapter(private val currentUserId: String) : 
    RecyclerView.Adapter<MessageAdapter.MessageViewHolder>() {

    private val messages = mutableListOf<Message>()

    fun setMessages(newMessages: List<Message>) {
        messages.clear()
        messages.addAll(newMessages)
        notifyDataSetChanged()
    }

    override fun getItemViewType(position: Int): Int {
        return if (messages[position].senderId == currentUserId) 1 else 0
    }
    
    override fun onBindViewHolder(holder: MessageViewHolder, position: Int) {
    val animation = AnimationUtils.loadAnimation(holder.itemView.context, R.anim.slide_up)
    holder.itemView.startAnimation(animation)
    holder.bind(messages[position])
}

    
    
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MessageViewHolder {
        val layout = if (viewType == 1) R.layout.item_message_sent else R.layout.item_message_received
        val view = LayoutInflater.from(parent.context).inflate(layout, parent, false)
        return MessageViewHolder(view)
    }

    override fun onBindViewHolder(holder: MessageViewHolder, position: Int) {
        holder.bind(messages[position])
    }

    override fun getItemCount() = messages.size

    class MessageViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val textMsg: TextView = view.findViewById(R.id.tvMessage)
        fun bind(message: Message) {
            
            textMsg.text = message.encryptedText 
        }
    }
}
