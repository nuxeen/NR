package com.student.securechat.ui

import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class RootWarningActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
     
        AlertDialog.Builder(this)
            .setTitle("Security Warning")
            .setMessage("This device is rooted. Security features may be compromised. Proceed with extreme caution.")
            .setPositiveButton("I Understand") { _, _ -> 
                
                finish() 
            }
            .setCancelable(false)
            .show()
    }
}
