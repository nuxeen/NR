package com.student.securechat.ui.profile

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.student.securechat.data.local.SecureStorage
import com.student.securechat.databinding.ActivityProfileBinding

class ProfileActivity : AppCompatActivity() {
    private lateinit var binding: ActivityProfileBinding
    private lateinit var secureStorage: SecureStorage

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProfileBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        secureStorage = SecureStorage(this)
        loadUserData()

        binding.btnSave.setOnClickListener {
            val newName = binding.etDisplayName.text.toString()
            if (newName.isNotEmpty()) {
                
                secureStorage.saveDisplayName(newName)
            }
        }
    }

    private fun loadUserData() {
        binding.etDisplayName.setText(secureStorage.getDisplayName())
    }
}
