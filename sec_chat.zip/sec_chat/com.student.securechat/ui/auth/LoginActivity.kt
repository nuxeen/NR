package com.student.securechat.ui.auth

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.student.securechat.core.security.BiometricAuth
import com.student.securechat.data.remote.AuthHelper
import com.student.securechat.databinding.ActivityLoginBinding
import com.student.securechat.ui.home.HomeActivity

class LoginActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnLogin.setOnClickListener {
            val email = binding.etEmail.text.toString()
            val password = binding.etPassword.text.toString()

            if (email.isNotEmpty() && password.isNotEmpty()) {
                AuthHelper.login(email, password,
                    onSuccess = {
                        checkBiometrics()
                    },
                    onError = { error ->
                        Toast.makeText(this, "Login Failed: $error", Toast.LENGTH_SHORT).show()
                    }
                )
            }
        }
    }

    private fun checkBiometrics() {
        val biometricAuth = BiometricAuth(this)
        biometricAuth.showPrompt(
            onSuccess = {
                startActivity(Intent(this, HomeActivity::class.java))
                finish()
            },
            onError = {
                Toast.makeText(this, "Biometric authentication required", Toast.LENGTH_SHORT).show()
            }
        )
    }
}
