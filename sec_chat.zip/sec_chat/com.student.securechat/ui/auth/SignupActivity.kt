package com.student.securechat.ui.auth

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.student.securechat.core.security.KeyStoreHelper
import com.student.securechat.data.remote.AuthHelper
import com.student.securechat.databinding.ActivitySignupBinding
import com.student.securechat.ui.home.HomeActivity

class SignupActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySignupBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySignupBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnSignup.setOnClickListener {
            val email = binding.etEmail.text.toString()
            val password = binding.etPassword.text.toString()

            if (email.isNotEmpty() && password.isNotEmpty()) {
                AuthHelper.signUp(email, password, 
                    onSuccess = {
                        
                        KeyStoreHelper.getOrCreateSecretKey()
                        
                        Toast.makeText(this, "Account Created Securely", Toast.LENGTH_SHORT).show()
                        startActivity(Intent(this, HomeActivity::class.java))
                        finish()
                    }, 
                    onError = { error ->
                        Toast.makeText(this, "Error: $error", Toast.LENGTH_LONG).show()
                    }
                )
            }
        }
    }
}
