package com.student.securechat.core.utils

import java.io.File

object RootDetector {
    private val rootPaths = arrayOf(
        "/system/app/Superuser.apk",
        "/sbin/su",
        "/system/bin/su",
        "/system/xbin/su",
        "/data/local/xbin/su",
        "/data/local/bin/su",
        "/system/sd/xbin/su",
        "/system/bin/failsafe/su",
        "/data/local/su"
    )

    fun isDeviceRooted(): Boolean {
        return checkRootPaths() || checkSuBinary()
    }

    private fun checkRootPaths(): Boolean {
        for (path in rootPaths) {
            if (File(path).exists()) return true
        }
        return false
    }

    private fun checkSuBinary(): Boolean {
        return try {
            Runtime.getRuntime().exec("which su").inputStream.bufferedReader().use { it.readLine() != null }
        } catch (e: Exception) {
            false
        }
    }
}
