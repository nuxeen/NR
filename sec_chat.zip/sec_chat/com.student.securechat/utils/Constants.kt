package com.student.securechat.core.utils

object Constants {
    const val USERS_COLLECTION = "users"
    const val CHATS_COLLECTION = "chats"
    const val PREFS_NAME = "secure_prefs"
    const val KEY_DISPLAY_NAME = "display_name"
}
