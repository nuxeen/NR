package com.student.securechat

import android.app.Application
import android.content.Intent
import com.student.securechat.core.utils.RootDetector
import com.student.securechat.ui.RootWarningActivity

class MyApp : Application() {

    override fun onCreate() {
        super.onCreate()

       
        if (RootDetector.isDeviceRooted()) {
            showRootWarning()
        }
    }

    private fun showRootWarning() {
     
        val intent = Intent(this, RootWarningActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        }
        startActivity(intent)
    }
}
