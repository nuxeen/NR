package com.student.securechat.data.model

data class User(
    val uid: String = "",
    val displayName: String = "",
    val avatarUrl: String = ""
)
