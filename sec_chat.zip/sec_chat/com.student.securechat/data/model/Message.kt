package com.student.securechat.data.model

data class Message(
    val senderId: String = "",
    val receiverId: String = "",
    val encryptedText: String = "",
    val timestamp: Long = System.currentTimeMillis()
)
