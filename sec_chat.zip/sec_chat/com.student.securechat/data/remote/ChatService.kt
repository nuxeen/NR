package com.student.securechat.data.remote

import com.google.firebase.firestore.FirebaseFirestore
import com.student.securechat.core.security.CryptoManager
import com.student.securechat.data.model.Message

object ChatService {
    private val db = FirebaseFirestore.getInstance()
    private const val CHATS_COLLECTION = "chats"

    fun sendMessage(senderId: String, receiverId: String, text: String) {
        val encryptedText = CryptoManager.encrypt(text)
        val message = Message(
            senderId = senderId,
            receiverId = receiverId,
            encryptedText = encryptedText,
            timestamp = System.currentTimeMillis()
        )

        db.collection(CHATS_COLLECTION).add(message)
    }

    fun listenForMessages(onMessageReceived: (Message) -> Unit) {
        db.collection(CHATS_COLLECTION)
            .orderBy("timestamp")
            .addSnapshotListener { snapshots, e ->
                if (e != null) return@addSnapshotListener

                for (doc in snapshots!!.documentChanges) {
                    val message = doc.document.toObject(Message::class.java)
                    onMessageReceived(message)
                }
            }
    }
}
