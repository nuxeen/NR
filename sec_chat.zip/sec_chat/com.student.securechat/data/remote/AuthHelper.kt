package com.student.securechat.data.remote

import com.google.firebase.auth.FirebaseAuth
import com.student.securechat.core.security.KeyStoreHelper

object AuthHelper {
    private val auth = FirebaseAuth.getInstance()

    fun signUp(email: String, pass: String, onSuccess: () -> Unit, onError: (String) -> Unit) {
        auth.createUserWithEmailAndPassword(email, pass)
            .addOnSuccessListener {
                KeyStoreHelper.getOrCreateSecretKey() 
                onSuccess()
            }
            .addOnFailureListener { onError(it.message ?: "Signup Failed") }
    }

    fun login(email: String, pass: String, onSuccess: () -> Unit, onError: (String) -> Unit) {
        auth.signInWithEmailAndPassword(email, pass)
            .addOnSuccessListener {
                KeyStoreHelper.getOrCreateSecretKey()
                onSuccess()
            }
            .addOnFailureListener { onError(it.message ?: "Login Failed") }
    }
}
