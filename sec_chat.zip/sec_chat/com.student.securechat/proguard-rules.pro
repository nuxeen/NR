-keep class com.google.firebase.** { *; }
-keep class com.google.android.gms.** { *; }

-keepclassmembers class com.student.securechat.data.model.** { *; }

-keep class androidx.biometric.** { *; }
-keep class androidx.security.crypto.** { *; }

-keep class com.student.securechat.core.utils.RootDetector { *; }
