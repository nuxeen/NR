package com.student.securechat.core.security

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.security.KeyStore
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey

object KeyStoreHelper {
    private const val ALIAS = "SecureChatKey"
    private const val ANDROID_KEYSTORE = "AndroidKeyStore"

    [span_4](start_span)// Generates or retrieves a hardware-backed AES key
    fun getOrCreateSecretKey(): SecretKey {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        
        [span_5](start_span)// Return existing key if it exists[span_5](end_span)
        keyStore.getKey(ALIAS, null)?.let { return it as SecretKey }

        [span_6](start_span)[span_7](start_span)// Otherwise, generate a new one[span_6](end_span)[span_7](end_span)
        val keyGenerator = KeyGenerator.getInstance(
            KeyProperties.KEY_ALGORITHM_AES, 
            ANDROID_KEYSTORE
        )

        val spec = KeyGenParameterSpec.Builder(
            ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM) 
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setUserAuthenticationRequired(false) 
            .setRandomizedEncryptionRequired(true)
            .build()

        keyGenerator.init(spec)
        return keyGenerator.generateKey()
    }
}
