package com.student.securechat.core.security

import android.util.Base64
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec

object CryptoManager {
    private const val TRANSFORMATION = "AES/GCM/NoPadding"
    
    [span_11](start_span)[span_12](start_span)// Encrypts text before it touches the internet[span_11](end_span)[span_12](end_span)
    fun encrypt(plainText: String): String {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, KeyStoreHelper.getOrCreateSecretKey())
        
        val iv = cipher.iv // Initialization Vector
        val encryptedBytes = cipher.doFinal(plainText.toByteArray())
        
        // We combine IV + Encrypted Data so we can decrypt it later
        val combined = iv + encryptedBytes
        return Base64.encodeToString(combined, Base64.DEFAULT)
    }

    [span_13](start_span)// Decrypts ciphertext for display in ChatActivity[span_13](end_span)
    fun decrypt(cipherText: String): String {
        val combined = Base64.decode(cipherText, Base64.DEFAULT)
        
        val iv = combined.sliceArray(0 until 12) // GCM IV is usually 12 bytes
        val encryptedData = combined.sliceArray(12 until combined.size)
        
        val cipher = Cipher.getInstance(TRANSFORMATION)
        val spec = GCMParameterSpec(128, iv)
        cipher.init(Cipher.DECRYPT_MODE, KeyStoreHelper.getOrCreateSecretKey(), spec)
        
        return String(cipher.doFinal(encryptedData))
    }
}
